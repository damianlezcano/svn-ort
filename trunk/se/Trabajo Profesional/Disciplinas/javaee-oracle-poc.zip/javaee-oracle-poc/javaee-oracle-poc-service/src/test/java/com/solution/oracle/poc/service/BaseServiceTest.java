package com.epidataconsulting.oracle.poc.service;

import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;


/**
 *
 * @author Adrian M. Paredes
 *
 */
public abstract class BaseServiceTest {
    
    protected static Context context;

    @BeforeClass
    public static void initContext() throws NamingException {

    }
    
    @AfterClass
    public static void closeContext() throws NamingException {
        if (context != null) {
            context.close();
        }
    }
}
