package com.solution.oracle.poc.service;


import com.solution.oracle.poc.model.Employee;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


@Stateless(name = "EmailService", mappedName = "javaee-oracle-poc/EmailService")
@Local(value = EmailService.class)
@Remote(value = EmailServiceRemote.class)
public class EmailServiceBean implements EmailService {

	void send(Employee employee, String message){		

		try
		{
			// Propiedades de la conexión
			Properties props = new Properties();
			props.setProperty("mail.smtp.host", "smtp.gmail.com");
			props.setProperty("mail.smtp.starttls.enable", "true");
			props.setProperty("mail.smtp.port", "587");
			props.setProperty("mail.smtp.user", "info@gmail.com");
			props.setProperty("mail.smtp.auth", "true");

			// Preparamos la sesion
			Session session = Session.getDefaultInstance(props);

			// Construimos el mensaje
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress("info@gmail.com"));
			message.addRecipient(
			Message.RecipientType.TO,
			new InternetAddress(employee.getMail()));
			message.setSubject("Enviado informacion");
			message.setText(message);

			// Lo enviamos.
			Transport t = session.getTransport("smtp");
			t.connect("info@gmail.com", "la clave");
			t.sendMessage(message, message.getAllRecipients());

			// Cierre.
			t.close();
		}	
			catch (Exception e)
		{
			e.printStackTrace();
		}
	}	
}
