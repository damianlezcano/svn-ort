package com.epidataconsulting.oracle.poc.service;


import com.epidataconsulting.oracle.poc.model.Employee;

import java.util.List;

import javax.ejb.Local;


@Local
public interface EmployeeService {
    
    void save(Employee employee);
    List<Employee> findByLastName(String lastName);
    void remove(Employee employee);
    List<Employee> findAll(Integer pageNumber, Integer pageSize);
    
}
