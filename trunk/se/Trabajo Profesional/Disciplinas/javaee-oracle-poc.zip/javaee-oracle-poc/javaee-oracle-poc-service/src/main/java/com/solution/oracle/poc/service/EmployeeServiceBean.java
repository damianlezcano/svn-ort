package com.solution.oracle.poc.service;


import com.solution.oracle.poc.model.Employee;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


@Stateless(name = "EmployeeService", mappedName = "javaee-oracle-poc/EmployeeService")
@Local(value = EmployeeService.class)
@Remote(value = EmployeeServiceRemote.class)
public class EmployeeServiceBean implements EmployeeService {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @EJB
    private EmailService emailService;

    @Override
    public void save(Employee employee) {
        entityManager.merge(employee);
    }

    @Override
    public List<Employee> findByLastName(String lastName) {
        Query query = entityManager.createNamedQuery(Employee.EMPLOYEE_FIND_BY_LAST_NAME);
        query.setParameter("lastName", "Paredes");              
        List<Employee> employees = query.getResultList();
        return employees;
    }


    @Override
    public void remove(Employee employee) {
        entityManager.remove(employee);
        emailService.send(employee, "Fue eliminado");
    }

    @Override
    public List<Employee> findAll(Integer pageNumber, Integer pageSize) {
        Query query = entityManager.createNamedQuery(Employee.EMPLOYEE_FIND_ALL);
        query.setFirstResult(pageNumber);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }
}
