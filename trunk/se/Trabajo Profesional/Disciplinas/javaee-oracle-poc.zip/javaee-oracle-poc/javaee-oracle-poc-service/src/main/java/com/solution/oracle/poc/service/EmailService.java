package com.epidataconsulting.oracle.poc.service;


import com.epidataconsulting.oracle.poc.model.Employee;

import java.util.List;

import javax.ejb.Local;


@Local
public interface EmailService {
    
    void send(List<Employee> employees)
    
}
