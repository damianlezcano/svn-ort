package com.epidataconsulting.oracle.poc.service;

import javax.ejb.Remote;


@Remote
public interface EmailServiceRemote extends EmailService {
}
