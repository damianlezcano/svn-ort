package com.epidataconsulting.oracle.poc.service;

import javax.ejb.Remote;

/**
 *
 * @author Adrian M. Paredes
 *
 */
@Remote
public interface EmployeeServiceRemote extends EmployeeService {
}
