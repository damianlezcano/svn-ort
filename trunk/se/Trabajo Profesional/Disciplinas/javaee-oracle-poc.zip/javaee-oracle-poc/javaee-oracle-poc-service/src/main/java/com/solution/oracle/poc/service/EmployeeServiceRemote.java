package com.epidataconsulting.oracle.poc.service;

import javax.ejb.Remote;

@Remote
public interface EmployeeServiceRemote extends EmployeeService {
}
