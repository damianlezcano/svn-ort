package com.epidataconsulting.oracle.poc.service;


import com.epidataconsulting.oracle.poc.model.Employee;
import com.epidataconsulting.oracle.poc.model.builder.EmployeeMockBuilder;

import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


/**
 *
 * @author Adrian M. Paredes
 *
 */
public class EmployeeServiceTest {
    
    private static final Logger logger = Logger.getLogger(EmployeeServiceTest.class);
    
    private EmployeeService service;
    
    @Before
    public void init() throws NamingException {
        Hashtable<String, String> properties = new Hashtable<String, String>();
        properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
        properties.put(Context.PROVIDER_URL, "t3://localhost:7001");
        Context context = new InitialContext(properties);
        service = (EmployeeServiceRemote) context.lookup("javaee-oracle-poc.EmployeeService#com.epidataconsulting.oracle.poc.service.EmployeeServiceRemote");
    }
    
    @Test
    public void persist() {
        service.save(EmployeeMockBuilder.createAdrianParedes());
    }
    
    @Test
    public void findByLastName() {
        List<Employee> employees = service.findByLastName("Paredes");
        Assert.assertNotNull(employees);
        Assert.assertTrue(employees.size() > 0);
        Employee employee = employees.get(0);
        Assert.assertEquals("Paredes", employee.getLastName());
        logger.debug("Nombre: " + employee.getName());
        logger.debug("Apellido: " + employee.getLastName());
        logger.debug("There are " + employees.size() + " with lastname Paredes...");
    }
}
