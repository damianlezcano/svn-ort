package com.epidataconsulting.oracle.poc.model;


import com.epidataconsulting.oracle.poc.model.builder.EmployeeMockBuilder;

import java.util.List;

import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import org.junit.Assert;
import org.junit.Test;


/**
 * Para ejecutar estos tests no se necesita tener levantado un Application Server,
 * ya que los mismos usan el persistence.xml de la carpeta src/test/resources/META-INF
 * que usan transacciones locales y tienen acceso directo a la base de datos alli
 * configurada
 *
 * @author Adrian M. Paredes
 *
 */
public class EmployeeTest extends BasePersistenceTest {

    private static Logger logger = Logger.getLogger(EmployeeTest.class);
    
    @Test
    public void persist() throws Exception {
        logger.debug("Creando Empleado...");
        Employee adrianp = EmployeeMockBuilder.createAdrianParedes();
        Employee ginos = EmployeeMockBuilder.createGinoSobrado();
        Employee damianl = EmployeeMockBuilder.createDamianLezcano();

        logger.debug("Abriendo transaccion JTA manualmente");
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        try {
            entityManager.merge(adrianp);
            entityManager.merge(ginos);
            entityManager.merge(damianl);
            tx.commit();
        } catch (Exception e) {
            tx.rollback();
            throw e;
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void find() {
        Query query = entityManager.createNamedQuery(Employee.EMPLOYEE_FIND_BY_LAST_NAME);
        query.setParameter("lastName", "Paredes");
        List<Employee> employees = query.getResultList();
        Assert.assertNotNull(employees);
        Assert.assertTrue(employees.size() > 0);
        Employee employee = employees.get(0);
        Assert.assertEquals("Paredes", employee.getLastName());
        logger.debug("Nombre: " + employee.getName());
        logger.debug("Apellido: " + employee.getLastName());
        logger.debug("There are " + employees.size() + " with lastname Paredes...");
    }

}
