package com.epidataconsulting.oracle.poc.model.builder;


import com.epidataconsulting.oracle.poc.model.Employee;
import com.epidataconsulting.oracle.poc.model.IdentityDocument;
import com.epidataconsulting.oracle.poc.model.Payslip;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;


public class EmployeeMockBuilder {
    
    private static final Logger logger = Logger.getLogger(EmployeeMockBuilder.class);
    
    private static Random random = new Random(new Date().getTime());

    public static Employee createAdrianParedes() {
        Employee employee = new Employee();
        employee.setName("Adrian");
        employee.setSecondName("Marcelo");
        employee.setLastName("Paredes");
        
        Long fileNumber = Math.abs(random.nextLong());
        employee.setFileNumber(fileNumber);
        logger.info("File Number = " + fileNumber);
        
        employee.setBirthday(new GregorianCalendar(1982, Calendar.JUNE, 3).getTime());

        IdentityDocument identityDocument = new IdentityDocument();
        identityDocument.setType("DNI");
        identityDocument.setNumber("29543783");
        employee.setIdentityDocument(identityDocument);

        Payslip october = new Payslip();
        october.setSalary(250000.0);
        october.setPaymentDate(new GregorianCalendar(2010, Calendar.OCTOBER, 30).getTime());

        Payslip november = new Payslip();
        november.setSalary(250000.0);
        november.setPaymentDate(new GregorianCalendar(2010, Calendar.NOVEMBER, 30).getTime());

        Payslip december = new Payslip();
        december.setSalary(250000.0);
        december.setPaymentDate(new GregorianCalendar(2010, Calendar.DECEMBER, 30).getTime());

        List<Payslip> payslips = new ArrayList<Payslip>();
        payslips.add(october);
        payslips.add(november);
        payslips.add(december);
        employee.setPayslips(payslips);

        return employee;
    }

    public static Employee createDamianLezcano() {
        Employee employee = new Employee();
        employee.setName("Damian");
        employee.setLastName("Lezcano");
        
        Long fileNumber = Math.abs(random.nextLong());
        employee.setFileNumber(fileNumber);
        logger.info("File Number = " + fileNumber);
        
        employee.setBirthday(new GregorianCalendar(1984, Calendar.JUNE, 3).getTime());

        IdentityDocument identityNumber = new IdentityDocument();
        identityNumber.setType("DNI");
        identityNumber.setNumber("30985111");
        employee.setIdentityDocument(identityNumber);

        return employee;
    }

    public static Employee createGinoSobrado() {
        Employee employee = new Employee();
        employee.setName("Gino");
        employee.setLastName("Sobrado");
        
        Long fileNumber = Math.abs(random.nextLong());
        employee.setFileNumber(fileNumber);
        logger.info("File Number = " + fileNumber);
        
        employee.setBirthday(new GregorianCalendar(1986, Calendar.JUNE, 3).getTime());

        IdentityDocument identityDocument = new IdentityDocument();
        identityDocument.setType("DNI");
        identityDocument.setNumber("32555111");
        employee.setIdentityDocument(identityDocument);

        return employee;
    }

}
