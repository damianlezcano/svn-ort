package com.epidataconsulting.oracle.poc.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;


/**
 *
 * @author Adrian M. Paredes
 *
 */
public abstract class BasePersistenceTest {

    private static EntityManagerFactory emFactory;

    protected static EntityManager entityManager;

    @BeforeClass
    public static void setUp() throws Exception {
        try {
            emFactory = Persistence.createEntityManagerFactory("javaee-oracle-poc-model");
            entityManager = emFactory.createEntityManager();
        } catch (Exception ex) {
            ex.printStackTrace();
            Assert.fail("Exception during JPA EntityManager instanciation.");
        }
    }

    @AfterClass
    public static void tearDown() throws Exception {
        if (entityManager != null) {
            entityManager.close();
        }
        if (emFactory != null) {
            emFactory.close();
        }
    }

}
