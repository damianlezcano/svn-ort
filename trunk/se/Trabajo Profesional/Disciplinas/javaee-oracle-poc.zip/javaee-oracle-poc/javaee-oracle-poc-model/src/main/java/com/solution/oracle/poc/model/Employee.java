package com.solution.oracle.poc.model;

import java.io.Serializable;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Adrian M. Paredes
 *
 */
@Entity
@NamedQueries({
    @NamedQuery(
        name = "Employee.findAll",
        query="select e from Employee e"),
    @NamedQuery(
        name = "Employee.findByLastName",
        query="select e FROM Employee e WHERE e.lastName = :lastName"),
    @NamedQuery(
        name = "Employee.findByFileNumber",
        query="select e FROM Employee e WHERE e.fileNumber = :fileNumber")
})
@SequenceGenerator(name = "EMPLOYEE_SEQ", sequenceName = "EMPLOYEE_SEQ", allocationSize = 50, initialValue = 50)
@Table(name = "EMPLOYEES")
public class Employee implements Serializable {

    @SuppressWarnings("compatibility:-4257518447367921997")
    private static final long serialVersionUID = 7205411068860065902L;
    
    public static final String EMPLOYEE_FIND_ALL = "Employee.findAll";
    public static final String EMPLOYEE_FIND_BY_LAST_NAME = "Employee.findByLastName";
    public static final String EMPLOYEE_FIND_BY_FILE_NUMBER = "Employee.findByFileNumber";
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EMPLOYEE_SEQ")
    @Column(name = "EMPLOYEE_ID")
    private Integer id;
    
    @Column(name = "NAME", nullable = false)
    private String name;
    
    @Column(name = "SECOND_NAME")
    private String secondName;
    
    @Column(name = "LAST_NAME", nullable = false)
    private String lastName;

    @Column(name = "LAST_MAIL", nullable = false)
    private String mail;
    
    @Column(name = "BIRTHDAY")
    @Temporal(TemporalType.DATE)
    private Date birthday;
    
    @Column(name = "FILE_NUMBER", nullable = false, unique = true)
    private Long fileNumber;
    
    @Embedded
    private IdentityDocument identityDocument;
    
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "EMPLOYEE_ID", referencedColumnName = "EMPLOYEE_ID")
    private List<Payslip> payslip;

    public Employee() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getMail() {
        return mail;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setFileNumber(Long fileNumber) {
        this.fileNumber = fileNumber;
    }

    public Long getFileNumber() {
        return fileNumber;
    }

    public void setIdentityDocument(IdentityDocument identityDocument) {
        this.identityDocument = identityDocument;
    }

    public IdentityDocument getIdentityDocument() {
        return identityDocument;
    }

    public void setPayslips(List<Payslip> payslip) {
        this.payslip = payslip;
    }

    public List<Payslip> getPayslip() {
        return payslip;
    }
    
}
