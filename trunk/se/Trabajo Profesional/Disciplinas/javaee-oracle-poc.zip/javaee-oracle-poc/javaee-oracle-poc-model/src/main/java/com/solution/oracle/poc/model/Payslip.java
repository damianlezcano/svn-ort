package com.epidataconsulting.oracle.poc.model;

import java.io.Serializable;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Adrian M. Paredes
 *
 */
@Entity
@NamedQueries( { @NamedQuery(name = "Payslip.findAll", query = "select o from Payslip o") })
@SequenceGenerator(name = "PAYSLIPS_SEQ", sequenceName = "PAYSLIPS_SEQ", allocationSize = 50, initialValue = 50)
@Table(name = "PAYSLIPS")
public class Payslip implements Serializable {

    @SuppressWarnings("compatibility:8629665482569191710")
    private static final long serialVersionUID = 2240752066451485170L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PAYSLIPS_SEQ")
    @Column(name = "PAYSLIP_ID")
    private Integer id;

    @Column(name = "SALARY", nullable = false)
    private Double salary;
    
    @Column(name = "PAYMENT_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date paymentDate;

    public Payslip() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Double getSalary() {
        return salary;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

}
