package com.epidataconsulting.oracle.poc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 *
 * @author Adrian M. Paredes
 *
 */
@Embeddable
public class IdentityDocument implements Serializable {

    @SuppressWarnings("compatibility:1352478102005982118")
    private static final long serialVersionUID = -3073434117875207650L;
    
    @Column(name = "DOCUMENT_TYPE", nullable = false)
    private String type;
    
    @Column(name = "DOCUMENT_NUMBER", nullable = false)
    private String number;

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getNumber() {
        return number;
    }
    
}
