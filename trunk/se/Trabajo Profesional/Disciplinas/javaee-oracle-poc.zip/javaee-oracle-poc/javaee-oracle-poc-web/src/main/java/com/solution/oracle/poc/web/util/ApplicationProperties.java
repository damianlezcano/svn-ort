package com.epidataconsulting.oracle.poc.web.util;

import java.io.InputStream;

import java.text.MessageFormat;

import java.util.Properties;


public class ApplicationProperties {

    private static Properties properties;

    private static final String APPLICATION_PROPERTY_FILE = "/application.properties";

    public static String read(String property) {
        if (properties == null) {
            readProperties();
        }
        String value = properties.getProperty(property);
        if (value == null) {
            throw new RuntimeException(MessageFormat.format("FATAL ERROR: application properties {0} not found in {1}",
                                                            property, APPLICATION_PROPERTY_FILE));
        }
        return value;
    }

    private static void readProperties() {
        InputStream is = null;
        try {
            is = ApplicationProperties.class.getResourceAsStream(APPLICATION_PROPERTY_FILE);
            properties = new Properties();
            properties.load(is);
        } catch (Exception e) {
            throw new RuntimeException(MessageFormat.format("Can not locate aplication configuration file: {0}",
                                                            APPLICATION_PROPERTY_FILE));
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (Exception ex) {
                throw new RuntimeException(MessageFormat.format("Can not close application configuration file: {0}",
                                                                APPLICATION_PROPERTY_FILE));
            }
        }
    }
}
