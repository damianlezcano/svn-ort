package com.epidataconsulting.oracle.poc.web.util;


import com.epidataconsulting.oracle.poc.service.EmployeeService;

import javax.ejb.EJB;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class ServiceLocatorContextListener implements ServletContextListener {

    @EJB
    private EmployeeService employeeService;

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        ServletContext context = servletContextEvent.getServletContext();
        context.setAttribute("employeeService", employeeService);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    }
}
