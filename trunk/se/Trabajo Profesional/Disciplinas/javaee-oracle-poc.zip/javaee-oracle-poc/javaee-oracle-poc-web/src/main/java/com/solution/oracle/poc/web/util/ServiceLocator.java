package com.epidataconsulting.oracle.poc.web.util;

import java.text.MessageFormat;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import javax.servlet.ServletContext;


public class ServiceLocator {

    public static Object getService(String serviceName) {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        ServletContext servletContext = (ServletContext) externalContext.getContext();
        Object service = servletContext.getAttribute(serviceName);
        if (service == null) {
            throw new RuntimeException(
                      MessageFormat.format("FATAL ERROR: Cannot locate service: {0}", serviceName));
        }
        return service;
    }

}
