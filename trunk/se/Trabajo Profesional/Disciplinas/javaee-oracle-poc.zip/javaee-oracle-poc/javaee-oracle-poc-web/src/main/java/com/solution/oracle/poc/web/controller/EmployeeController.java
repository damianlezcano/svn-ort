package com.solution.oracle.poc.web.controller;


import com.solution.oracle.poc.model.Employee;
import com.solution.oracle.poc.model.IdentityDocument;
import com.solution.oracle.poc.service.EmployeeService;
import com.solution.oracle.poc.web.util.ServiceLocator;

import java.util.List;

import org.apache.log4j.Logger;


/**
 * @author Damian Lezcano
 *
 */
public class EmployeeController {

    private List<Employee> employees;
    
    private Employee employee;
    
    private EmployeeService employeeService;
    
    private static final Logger logger = Logger.getLogger(EmployeeController.class);

    public EmployeeController() {
        employeeService = (EmployeeService) ServiceLocator.getService("employeeService");
    }
    
    public void newEmployee() {
        logger.info("--- Creating new employee...");
        employee = new Employee();
        employee.setIdentityDocument(new IdentityDocument());
    }
    
    public void save() {
        if (employee.getId() == null) {
            employees.add(employee);
            logger.info("--- Saving new employee: " + employee.getName());
        } else {
            logger.info("--- Updating employee: " + employee.getName());
        }
        employeeService.save(employee);
        employee = null;
    }

    public void cancel() {
        employee = null;
    }

    public void remove() {
        logger.info("--- Removing employee: " + employee.getName());
        employees.remove(employee);
        employeeService.remove(employee);
        employee = null;
    }
    
    public void update() {
        logger.info("--- Updating employee: " + employee.getName());
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public List<Employee> getEmployees() {
        if (employees == null) {
                logger.info("--- Obteniendo empleados ---");
                employees = employeeService.findAll(0, 15);
        }
        return employees;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Employee getEmployee() {
        return employee;
    }

}
